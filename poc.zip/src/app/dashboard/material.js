"use strict";
var Material = (function () {
    function Material() {
    }
    return Material;
}());
exports.Material = Material;
//# sourceMappingURL=material.js.map