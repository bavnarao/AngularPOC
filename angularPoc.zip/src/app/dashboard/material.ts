export class Material {
    mid: string;
    mname: string;
    toq: number;
    taq: number;
    tsq: number;
    uom: string;
    sq: number;
    status: string;
}