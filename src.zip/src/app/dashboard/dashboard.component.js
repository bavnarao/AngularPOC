/// <reference path="../jquery.d.ts"/>
"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var material_service_1 = require("./material.service");
//import {AgGridNg2} from 'ag-grid-ng2/main';
var DashboardComponent = (function () {
    function DashboardComponent(service) {
        this.service = service;
        this.searchText = "";
        //this.materials = new Array<Material>();
    }
    DashboardComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.service.getMaterials().subscribe(function (data) { return _this.materials = data; }, function (error) { return _this.errorMessage = error; });
        $("#imagesList").show();
        $("#jobsTable").show();
        $("#recentDocTitle").show();
    };
    DashboardComponent.prototype.promise = function (data) {
        for (var index = 0; index < data.length; index++) {
            var widthV = data[index].toq;
            $('.bar')[index].style.width = widthV + "%";
            if (data[index].status == "Error") {
                $('.slb-progress-indicator')[index].className = "slb-progress-indicator warning";
                $('.bar')[index].style.width = "100%";
            }
            else {
                $('.slb-progress-indicator')[index].className = "slb-progress-indicator positive";
            }
        }
    };
    DashboardComponent.prototype.onKill = function () {
    };
    DashboardComponent.prototype.getlist = function () {
        var _this = this;
        this.service.getMaterials().subscribe(function (data) { return _this.promise(data); }, function (error) { return _this.errorMessage = error; });
        document.getElementById("contentTitle").innerHTML = "Job List";
        $('#menu4').hide();
        $('#menu5').hide();
        $("#imagesList").hide();
        $("#jobsTable").show();
        $('a').removeClass('selected');
        $("#joblst").addClass("framework-nav-item selected");
        $("#recentDocTitle").hide();
    };
    DashboardComponent.prototype.getimageData = function (evt) {
        evt = event.currentTarget;
        var abc = evt.offsetParent.innerText;
        alert(abc);
    };
    DashboardComponent.prototype.getdashboard = function () {
        var _this = this;
        document.getElementById("contentTitle").innerHTML = "My Dashboard";
        this.service.getMaterials().subscribe(function (data) { return _this.materials = data; }, function (error) { return _this.errorMessage = error; });
        $("#imagesList").show();
        $("#jobsTable").show();
        $("NAV > a").addClass("framework-nav-item");
        $('a').removeClass('selected');
        $("#dashboard").addClass("framework-nav-item selected");
        $('#menu4').hide();
        $('#menu5').hide();
        $('#menu3').hide();
        $("#recentDocTitle").show();
    };
    DashboardComponent.prototype.getdrive = function () {
        document.getElementById("contentTitle").innerHTML = "Seismic Drive";
        $("#imagesList").hide();
        $("#jobsTable").hide();
        $('#menu4').hide();
        $('#menu5').hide();
        $('#menu3').show();
        $('#menu3').addClass("tab-pane fade in active");
        $('a').removeClass('selected');
        $("#seismicDrive").addClass("framework-nav-item selected");
        $("#recentDocTitle").hide();
    };
    DashboardComponent.prototype.getflow = function () {
        document.getElementById("contentTitle").innerHTML = "Flow Designer";
        $('a').removeClass('selected');
        $("#flowDesign").addClass("framework-nav-item selected");
        $("#imagesList").show();
        $("#jobsTable").hide();
        $('#menu4').hide();
        $('#menu3').hide();
        $('#menu5').hide();
        $("#recentDocTitle").show();
    };
    DashboardComponent.prototype.getview = function () {
        $('a').removeClass('selected');
        $("#viewer").addClass("framework-nav-item selected");
        $("#imagesList").hide();
        $('#menu5').show();
        $("#jobsTable").hide();
        $('#menu3').hide();
        $('#menu4').hide();
        $('#menu5').addClass("tab-pane fade in active");
        document.getElementById("contentTitle").innerHTML = "Viewer";
        $("#recentDocTitle").hide();
    };
    DashboardComponent = __decorate([
        core_1.Component({
            selector: "my-app",
            moduleId: module.id,
            templateUrl: "./dashboardView.html",
            providers: [material_service_1.MaterialService]
        }), 
        __metadata('design:paramtypes', [material_service_1.MaterialService])
    ], DashboardComponent);
    return DashboardComponent;
}());
exports.DashboardComponent = DashboardComponent;
//# sourceMappingURL=dashboard.component.js.map